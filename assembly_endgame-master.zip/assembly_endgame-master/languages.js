export const languages = [
  
  {
    title: "html Logo",
    src: "/images/html.png",
    isOn: true
  },
  {
    title: "css Logo",
    src: "/images/css.svg",
    isOn: true
  },
  {
    title: "javascript Logo",
    src: "/images/javascript.png",
    isOn: true
  },
  {
    title: "react Logo",
    src: "/images/react.png",
    isOn: true
  },
  {
    title: "typescript Logo",
    src: "/images/typescript.png",
    isOn: true
  },
  {
    title: "node Logo",
    src: "/images/node.png",
    isOn: true
  },
  {
    title: "python Logo",
    src: "/images/python.png",
    isOn: true
  },
  {
    title: "assembly Logo",
    src: "/images/assembly.png",
    isOn: true
  },

]
  

